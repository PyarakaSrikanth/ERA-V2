// ProfilePulse content script: injects sidebar UI, observes LinkedIn feed, saves trends, and drafts posts

(function initProfilePulse() {
  if (window.__PROFILE_PULSE_LOADED__) return;
  window.__PROFILE_PULSE_LOADED__ = true;

  const ACCENT = '#6B8AFB';

  const state = {
    sidebarOpen: false,
    detectedPosts: new Map(),
  };

  function createSidebar() {
    const container = document.createElement('div');
    container.className = 'pp-sidebar';
    container.innerHTML = `
      <div class="pp-header">
        <div class="pp-logo">ProfilePulse</div>
        <button class="pp-close" aria-label="Close">✕</button>
      </div>
      <div class="pp-tabs">
        <button data-tab="insights" class="active">Insights</button>
        <button data-tab="trends">Trends</button>
        <button data-tab="composer">Composer</button>
      </div>
      <div class="pp-panels">
        <section data-panel="insights" class="active">
          <div class="pp-card">
            <div class="pp-card-title">Today</div>
            <div class="pp-grid">
              <div class="pp-metric"><div class="pp-metric-value" id="pp-metric-posts">–</div><div class="pp-metric-label">Posts scanned</div></div>
              <div class="pp-metric"><div class="pp-metric-value" id="pp-metric-trending">–</div><div class="pp-metric-label">Trending found</div></div>
            </div>
          </div>
          <div class="pp-card">
            <div class="pp-card-title">Optimal windows</div>
            <div id="pp-best-windows" class="pp-pills"></div>
          </div>
        </section>
        <section data-panel="trends">
          <div id="pp-trend-list" class="pp-list"></div>
        </section>
        <section data-panel="composer">
          <div class="pp-card">
            <label class="pp-label">Goal</label>
            <select id="pp-goal">
              <option value="insight">Share insight</option>
              <option value="story">Tell a story</option>
              <option value="tips">Tactical tips</option>
              <option value="contrarian">Contrarian take</option>
            </select>
            <label class="pp-label">Draft</label>
            <textarea id="pp-draft" rows="8" placeholder="Paste your idea or let AI help you craft a strong hook..."></textarea>
            <div class="pp-row">
              <label class="pp-label">Tone</label>
              <select id="pp-tone">
                <option>professional</option>
                <option>friendly</option>
                <option>bold</option>
                <option>analytical</option>
              </select>
              <button id="pp-draft-ai" class="pp-primary">Predict & Draft</button>
            </div>
            <div id="pp-ai-output" class="pp-output" hidden></div>
          </div>
        </section>
      </div>
    `;
    document.body.appendChild(container);

    const closeBtn = container.querySelector('.pp-close');
    closeBtn?.addEventListener('click', toggleSidebar);

    const tabs = container.querySelectorAll('.pp-tabs button');
    tabs.forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));

    const draftBtn = container.querySelector('#pp-draft-ai');
    draftBtn?.addEventListener('click', onDraftAI);

    return container;
  }

  function ensureToggle() {
    if (document.querySelector('.pp-fab')) return;
    const fab = document.createElement('button');
    fab.className = 'pp-fab';
    fab.title = 'Open ProfilePulse';
    fab.innerHTML = '<span class="pp-fab-dot"></span>';
    fab.addEventListener('click', toggleSidebar);
    document.body.appendChild(fab);
  }

  function toggleSidebar() {
    state.sidebarOpen = !state.sidebarOpen;
    const el = document.querySelector('.pp-sidebar');
    if (el) {
      el.classList.toggle('open', state.sidebarOpen);
    }
  }

  function switchTab(tab) {
    document.querySelectorAll('.pp-tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.pp-panels > section').forEach(p => p.classList.toggle('active', p.dataset.panel === tab));
  }

  function observeFeed() {
    const trendList = document.getElementById('pp-trend-list');
    const postsMetric = document.getElementById('pp-metric-posts');
    const trendingMetric = document.getElementById('pp-metric-trending');

    const root = document.querySelector('main') || document.body;
    const mo = new MutationObserver(() => scan());
    mo.observe(root, { childList: true, subtree: true });
    scan();

    function scan() {
      const posts = document.querySelectorAll('div.feed-shared-update-v2, div.occludable-update, article, div.update-components-actor');
      let trendingCount = 0;
      postsMetric && (postsMetric.textContent = String(posts.length));
      posts.forEach(node => {
        if (state.detectedPosts.has(node)) return;
        const post = extractPost(node);
        if (!post) return;
        state.detectedPosts.set(node, post);
        injectSaveButton(node, post);
        if (post.velocityScore >= 0.7) trendingCount += 1;
      });
      trendingMetric && (trendingMetric.textContent = String(trendingCount));
      renderTrendList();
    }

    function renderTrendList() {
      if (!trendList) return;
      const items = [...state.detectedPosts.values()]
        .filter(p => p.velocityScore >= 0.7)
        .sort((a,b) => b.velocityScore - a.velocityScore)
        .slice(0, 20);
      trendList.innerHTML = items.map(p => `
        <div class="pp-list-item">
          <div>
            <div class="pp-item-title">${escapeHtml(p.author || 'Unknown')}</div>
            <div class="pp-item-sub">❤ ${p.likes}  💬 ${p.comments}  # ${p.hashtags.slice(0,3).join(' ')}</div>
          </div>
          <button class="pp-secondary" data-save="${encodeURIComponent(p.url || location.href)}">Save</button>
        </div>
      `).join('');
      trendList.querySelectorAll('button[data-save]').forEach(btn => {
        btn.addEventListener('click', () => {
          const url = decodeURIComponent(btn.getAttribute('data-save'));
          const match = items.find(i => (i.url || location.href) === url);
          if (match) openSaveDialog(match);
        });
      });
    }
  }

  function extractPost(node) {
    try {
      const text = (node.textContent || '').trim();
      const hashtags = Array.from(new Set((text.match(/#\w+/g) || []).map(s => s.trim())));
      const likes = parseCount(text.match(/(\d+[,.]?\d*[kK]?)(?=\s*likes|\s*reactions)/i)?.[1]);
      const comments = parseCount(text.match(/(\d+[,.]?\d*[kK]?)(?=\s*comments?)/i)?.[1]);
      const hours = parseCount(text.match(/(\d+)(?=\s*h\b|\s*hours?)/i)?.[1]) || 24;
      const author = node.querySelector('span.update-components-actor__title, a.app-aware-link, span.feed-shared-actor__title')?.textContent?.trim();
      const url = node.querySelector('a.app-aware-link[href*="/feed/update/"]')?.href || location.href;
      const engagement = (likes + comments * 2);
      const velocity = engagement / Math.max(1, hours);
      const velocityScore = Math.max(0, Math.min(1, normalize(velocity, 0, 200)));
      return { text, hashtags, likes, comments, hours, author, url, velocityScore };
    } catch (e) {
      return null;
    }
  }

  function injectSaveButton(node, post) {
    const already = node.querySelector('.pp-save');
    if (already) return;
    const btn = document.createElement('button');
    btn.className = 'pp-save';
    btn.textContent = 'Pulse';
    btn.title = 'Save trend note';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      openSaveDialog(post);
    });
    (node.querySelector('footer') || node).appendChild(btn);
  }

  function openSaveDialog(post) {
    const dlg = document.createElement('div');
    dlg.className = 'pp-dialog';
    dlg.innerHTML = `
      <div class="pp-dialog-card">
        <div class="pp-dialog-title">Save Trend Note</div>
        <label class="pp-label">Tags</label>
        <input id="pp-tags" value="${escapeHtml(post.hashtags.join(' '))}" />
        <label class="pp-label">Angle idea</label>
        <textarea id="pp-note" rows="4" placeholder="Hook, angle, outline snippet..."></textarea>
        <div class="pp-row end">
          <button class="pp-secondary" id="pp-cancel">Cancel</button>
          <button class="pp-primary" id="pp-save">Save</button>
        </div>
      </div>
    `;
    document.body.appendChild(dlg);
    dlg.querySelector('#pp-cancel')?.addEventListener('click', () => dlg.remove());
    dlg.querySelector('#pp-save')?.addEventListener('click', async () => {
      const tags = dlg.querySelector('#pp-tags')?.value || '';
      const note = dlg.querySelector('#pp-note')?.value || '';
      const md = buildNoteMarkdown(post, note, tags);
      const metadata = buildMetadata(post, tags);
      await chrome.runtime.sendMessage({ type: 'PP_DOWNLOAD_ARTIFACTS', payload: { noteMarkdown: md, metadataJson: metadata, baseFileName: slugify((post.hashtags[0] || post.author || 'trend')) } });
      dlg.remove();
    });
  }

  async function onDraftAI() {
    const tone = document.getElementById('pp-tone')?.value || 'professional';
    const goal = document.getElementById('pp-goal')?.value || 'insight';
    const draft = document.getElementById('pp-draft')?.value || '';
    const systemPrompt = `You are ProfilePulse, a LinkedIn post writing expert. Optimize for scannability, strong hooks, and non-clickbait clarity.`;
    const userPrompt = `Goal: ${goal}\nTone: ${tone}\nDraft or context:\n${draft}\n\nReturn 2 post variants with line breaks, a compelling hook, and 3 relevant hashtags.`;
    const out = document.getElementById('pp-ai-output');
    out.hidden = false;
    out.textContent = 'Thinking…';
    try {
      const { ok, result, error } = await chrome.runtime.sendMessage({ type: 'PP_CALL_LLM', payload: { systemPrompt, userPrompt, temperature: 0.7, maxTokens: 450 } });
      if (!ok) throw new Error(error || 'LLM failed');
      out.innerHTML = '';
      const variants = result.split(/\n\s*\n/).slice(0,2);
      variants.forEach((v, i) => {
        const card = document.createElement('div');
        card.className = 'pp-variant';
        card.innerHTML = `<div class="pp-variant-title">Variant ${i+1}</div><pre class="pp-pre">${escapeHtml(v.trim())}</pre><button class="pp-secondary">Copy</button>`;
        card.querySelector('button')?.addEventListener('click', () => navigator.clipboard.writeText(v.trim()));
        out.appendChild(card);
      });
    } catch (e) {
      out.textContent = 'Error: ' + (e?.message || String(e));
    }
  }

  function buildNoteMarkdown(post, note, tags) {
    return `# Trend Note — ${post.hashtags[0] || post.author || 'LinkedIn'}\n- Source: ${post.url || location.href}\n- Author: ${post.author || 'Unknown'}\n- Captured: ${new Date().toISOString()}\n- Entities: ${post.hashtags.join(' ')}\n\n## Why it’s trending\n${note || '—'}\n\n## Post outline\n- Hook:\n- Insight:\n- Example:\n- CTA:\n\nTags: ${tags}`;
  }

  function buildMetadata(post, tags) {
    return {
      sourceUrl: post.url || location.href,
      author: post.author || 'Unknown',
      capturedAt: new Date().toISOString(),
      stats: { likes: post.likes, comments: post.comments, hours: post.hours, velocityScore: post.velocityScore },
      entities: { hashtags: post.hashtags, tags: (tags || '').split(/\s+/).filter(Boolean) },
      pageTitle: document.title,
    };
  }

  function parseCount(str) {
    if (!str) return 0;
    const s = String(str).replace(/[,\s]/g, '').toLowerCase();
    if (s.endsWith('k')) return Math.round(parseFloat(s) * 1000);
    if (s.endsWith('m')) return Math.round(parseFloat(s) * 1000000);
    const n = parseInt(s, 10);
    return isNaN(n) ? 0 : n;
  }

  function normalize(val, min, max) {
    return (val - min) / Math.max(1, (max - min));
  }

  function slugify(s) {
    return String(s || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')
      .slice(0, 60);
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Boot
  createSidebar();
  ensureToggle();
  observeFeed();
})();

